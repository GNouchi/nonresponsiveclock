from django.apps import AppConfig


class SessionAppConfig(AppConfig):
    name = 'session_app'
